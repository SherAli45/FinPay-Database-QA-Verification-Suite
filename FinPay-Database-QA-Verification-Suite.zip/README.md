<div align="center">

  <h1>💳 FinPay — Database QA & Financial Reconciliation Engine</h1>
  <p><b>Enterprise SQL Verification Suite for Core Banking Ledgers, Data Integrity & Anomaly Audits</b></p>

  <p align="center">
    <img src="https://img.shields.io/badge/PostgreSQL-14%2B-316192?style=for-the-badge&logo=postgresql&logoColor=white" alt="PostgreSQL" />
    <img src="https://img.shields.io/badge/SQL-Advanced_Queries-CC292B?style=for-the-badge&logo=microsoftsqlserver&logoColor=white" alt="SQL" />
    <img src="https://img.shields.io/badge/CI%2FCD-GitHub_Actions-2088FF?style=for-the-badge&logo=githubactions&logoColor=white" alt="CI/CD" />
    <img src="https://img.shields.io/badge/QA-Zero_Defect_Ledger-0F766E?style=for-the-badge&logo=checkmarx&logoColor=white" alt="QA" />
  </p>

  <p align="center">
    <a href="https://www.linkedin.com/in/sher-ali-b07457347" target="_blank">
      <img src="https://img.shields.io/badge/Author-Sher_Ali_(QA_Engineer)-0A66C2?style=flat-square&logo=linkedin&logoColor=white" alt="LinkedIn" />
    </a>
    &nbsp;
    <a href="mailto:s38454672@gmail.com">
      <img src="https://img.shields.io/badge/Email-s38454672%40gmail.com-D14836?style=flat-square&logo=gmail&logoColor=white" alt="Email" />
    </a>
  </p>

</div>

---

## 📌 Executive Summary

In high-volume financial applications, application-layer UI testing is not enough. Critical monetary bugs—such as **race-condition balance drift, floating-point rounding leakage, and orphaned ledger rows**—often slip past web tests directly into the database.

**FinPay DB-QA Engine** is an enterprise-grade SQL verification and reconciliation framework. It audits a double-entry ledger, enforces referential integrity, detects boundary overflows, and flags fraudulent velocity spikes directly at the database tier.

---

## 🏗️ Core Architecture & Ledger Design

```
   ┌──────────────────────────────────────────────┐
   │            ACCOUNTS (KYC & Profile)          │
   └──────────────────────┬───────────────────────┘
                          │ 1 : N
   ┌──────────────────────▼───────────────────────┐
   │             WALLETS (USD Ledger)             │
   └──────────┬───────────────────────┬───────────┘
              │ Sender                │ Receiver
   ┌──────────▼───────────────────────▼───────────┐
   │          TRANSACTIONS (State & Fees)         │
   └──────────────────────┬───────────────────────┘
                          │ 1 : 2
   ┌──────────────────────▼───────────────────────┐
   │   DOUBLE-ENTRY AUDIT LEDGER (DEBIT/CREDIT)   │
   └──────────────────────────────────────────────┘
```

---

## 🧪 QA Test Suites Breakdown

| Suite | File | Focus & Business Rules |
| :--- | :--- | :--- |
| **01. Data Integrity** | [`01_data_integrity_tests.sql`](./test_suites/01_data_integrity_tests.sql) | Foreign key cascades, orphaned wallets, NULL checks, self-transfer prevention. |
| **02. Financial Reconciliation** | [`02_financial_reconciliation_audit.sql`](./test_suites/02_financial_reconciliation_audit.sql) | Double-entry invariant: `SUM(Debits) == SUM(Credits)`, 1% fee precision, wallet balance drift. |
| **03. Boundary & Constraints** | [`03_boundary_and_constraint_tests.sql`](./test_suites/03_boundary_and_constraint_tests.sql) | Negative balance prevention, 24h transfer limits, decimal precision overflow. |
| **04. Fraud & Anomaly Audit** | [`04_fraud_and_anomaly_detection.sql`](./test_suites/04_fraud_and_anomaly_detection.sql) | Micro-burst transactions (>5 tx in 2 min), transfers on locked wallets, KYC tier checks. |

---

## 💡 Highlight: Double-Entry Financial Reconciliation Query

The following SQL query proves that for every completed transaction, the debited principal exactly equals credited funds:

```sql
SELECT 
    t.transaction_id,
    t.transaction_ref,
    COALESCE(SUM(CASE WHEN al.entry_type = 'DEBIT' THEN (al.amount - t.fee) ELSE 0 END), 0) AS total_principal_debit,
    COALESCE(SUM(CASE WHEN al.entry_type = 'CREDIT' THEN al.amount ELSE 0 END), 0) AS total_principal_credit,
    CASE 
        WHEN COALESCE(SUM(CASE WHEN al.entry_type = 'DEBIT' THEN (al.amount - t.fee) ELSE 0 END), 0) <>
             COALESCE(SUM(CASE WHEN al.entry_type = 'CREDIT' THEN al.amount ELSE 0 END), 0)
        THEN 'FAIL: Unbalanced double-entry ledger'
        ELSE 'PASS'
    END AS status
FROM transactions t
JOIN audit_ledger al ON t.transaction_id = al.transaction_id
WHERE t.transaction_status = 'COMPLETED'
GROUP BY t.transaction_id, t.transaction_ref, t.amount, t.fee
HAVING COALESCE(SUM(CASE WHEN al.entry_type = 'DEBIT' THEN (al.amount - t.fee) ELSE 0 END), 0) <>
       COALESCE(SUM(CASE WHEN al.entry_type = 'CREDIT' THEN al.amount ELSE 0 END), 0);
```

---

## 🚀 Running the Automated Runner Locally

### Prerequisites:
- Node.js 16+
- PostgreSQL or Docker

```bash
# 1. Clone repository
git clone https://github.com/SherAli45/FinPay-Database-QA-Verification-Suite.git
cd FinPay-Database-QA-Verification-Suite

# 2. Setup Database
psql -U postgres -d postgres -f schema/01_init_schema.sql
psql -U postgres -d postgres -f schema/02_seed_data.sql

# 3. Install runner & execute test suite
cd automated_runner
npm install
npm test
```

---

## 📊 Sample CLI Execution Report

```text
======================================================
🚀 FINPAY DATABASE QA AUTOMATED TEST SUITE
🎯 Target Database: finpay_qa_db@localhost:5432
======================================================

📋 Executing Suite 01: Data Integrity & Relationships...
  ✅ [PASS] TC-DB-INT-01: 0 defect rows detected.
  ✅ [PASS] TC-DB-INT-02: 0 defect rows detected.
  ✅ [PASS] TC-DB-INT-03: 0 defect rows detected.
  ✅ [PASS] TC-DB-INT-04: 0 defect rows detected.

📋 Executing Suite 02: Financial Reconciliation & Ledger...
  ✅ [PASS] TC-DB-REC-01: 0 defect rows detected.
  ✅ [PASS] TC-DB-REC-02: 0 defect rows detected.
  ✅ [PASS] TC-DB-REC-03: 0 defect rows detected.

======================================================
📊 QA EXECUTION SUMMARY
Total Test Queries: 12
✅ Passed: 12
❌ Failed: 0
Success Rate: 100.0%
======================================================
```

---

## 📑 QA Deliverables Included

- 📋 [Master Database Test Plan](./test_documentation/DATABASE_TEST_PLAN.md)
- 🐞 [Real-World Bug Defect Log & Remediation](./test_documentation/DEFECT_LOG_BUG_REPORTS.md)
- ⚙️ [Automated GitHub Actions CI Workflow](./.github/workflows/db-tests.yml)

---

## 👨‍💻 Author & Contact

**Sher Ali**  
*Software Quality Assurance Engineer*  
- 💼 **LinkedIn:** [sher-ali-b07457347](https://www.linkedin.com/in/sher-ali-b07457347)  
- 📧 **Email:** [s38454672@gmail.com](mailto:s38454672@gmail.com)  
- 🌐 **GitHub:** [@SherAli45](https://github.com/SherAli45)  
