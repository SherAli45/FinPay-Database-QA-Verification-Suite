-- ==============================================================================
-- FINPAY DATABASE SEED DATA & TEST FIXTURES
-- Description: Test datasets including baseline active data and edge-case profiles
-- ==============================================================================

-- 1. Insert Baseline Accounts
INSERT INTO accounts (account_number, full_name, email, account_status, kyc_verified) VALUES
('ACC-1001', 'Alice Johnson', 'alice.j@example.com', 'ACTIVE', TRUE),
('ACC-1002', 'Bob Smith', 'bob.s@example.com', 'ACTIVE', TRUE),
('ACC-1003', 'Charlie Brown', 'charlie.b@example.com', 'SUSPENDED', FALSE),
('ACC-1004', 'Diana Prince', 'diana.p@example.com', 'ACTIVE', TRUE),
('ACC-1005', 'Edward Nygma', 'edward.n@example.com', 'UNDER_REVIEW', TRUE);

-- 2. Insert Wallets
INSERT INTO wallets (account_id, wallet_type, currency, balance, daily_transfer_limit, is_locked) VALUES
(1, 'STANDARD', 'USD', 2500.00, 5000.00, FALSE), -- Alice Wallet 1 (USD)
(2, 'STANDARD', 'USD', 1200.50, 5000.00, FALSE), -- Bob Wallet 2 (USD)
(3, 'STANDARD', 'USD', 0.00, 1000.00, TRUE),     -- Charlie Wallet 3 (Locked & 0 balance)
(4, 'PREMIUM', 'USD', 15000.00, 50000.00, FALSE), -- Diana Wallet 4 (High Net Worth)
(5, 'STANDARD', 'USD', 350.00, 500.00, FALSE);    -- Edward Wallet 5 (Under Review)

-- 3. Insert Historical Completed Transactions
INSERT INTO transactions (transaction_ref, sender_wallet_id, receiver_wallet_id, amount, fee, transaction_status, idempotency_key, created_at) VALUES
('TX-REF-8801', 1, 2, 200.00, 2.00, 'COMPLETED', 'IDEMP-KEY-001', CURRENT_TIMESTAMP - INTERVAL '2 days'),
('TX-REF-8802', 4, 1, 1000.00, 10.00, 'COMPLETED', 'IDEMP-KEY-002', CURRENT_TIMESTAMP - INTERVAL '1 day'),
('TX-REF-8803', 2, 5, 50.00, 0.50, 'COMPLETED', 'IDEMP-KEY-003', CURRENT_TIMESTAMP - INTERVAL '12 hours'),
('TX-REF-8804', 1, 3, 100.00, 1.00, 'FAILED', 'IDEMP-KEY-004', CURRENT_TIMESTAMP - INTERVAL '2 hours'); -- Target wallet was locked

-- 4. Insert Audit Ledger Entries for Completed Transactions (Double-Entry Bookkeeping)
-- For TX-REF-8801: Sender (Wallet 1) debited $202.00 ($200 + $2 fee), Receiver (Wallet 2) credited $200.00
INSERT INTO audit_ledger (transaction_id, wallet_id, entry_type, amount, balance_after, recorded_at) VALUES
(1, 1, 'DEBIT', 202.00, 2500.00, CURRENT_TIMESTAMP - INTERVAL '2 days'),
(1, 2, 'CREDIT', 200.00, 1200.50, CURRENT_TIMESTAMP - INTERVAL '2 days');

-- For TX-REF-8802: Sender (Wallet 4) debited $1010.00, Receiver (Wallet 1) credited $1000.00
INSERT INTO audit_ledger (transaction_id, wallet_id, entry_type, amount, balance_after, recorded_at) VALUES
(2, 4, 'DEBIT', 1010.00, 15000.00, CURRENT_TIMESTAMP - INTERVAL '1 day'),
(2, 1, 'CREDIT', 1000.00, 2700.00, CURRENT_TIMESTAMP - INTERVAL '1 day');

-- For TX-REF-8803: Sender (Wallet 2) debited $50.50, Receiver (Wallet 5) credited $50.00
INSERT INTO audit_ledger (transaction_id, wallet_id, entry_type, amount, balance_after, recorded_at) VALUES
(3, 2, 'DEBIT', 50.50, 1150.00, CURRENT_TIMESTAMP - INTERVAL '12 hours'),
(3, 5, 'CREDIT', 50.00, 350.00, CURRENT_TIMESTAMP - INTERVAL '12 hours');

-- 5. Insert Fraud Test Alerts
INSERT INTO fraud_alerts (transaction_id, wallet_id, risk_score, trigger_rule, alert_status) VALUES
(4, 3, 85, 'TRANSFER_TO_LOCKED_WALLET', 'RESOLVED');
