-- ==============================================================================
-- SUITE 02: FINANCIAL RECONCILIATION & DOUBLE-ENTRY LEDGER AUDIT
-- Focus: Bookkeeping equality, Ledger vs Wallet balance drift, Fee calculations
-- ==============================================================================

-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-REC-01 (Double-Entry Balance Verification)
-- Objective: Ensure that for every completed transaction, the Debited Principal
--            equals the Credited Principal (excluding explicit system fees).
-- Business Rule: Total Principal Debit == Total Principal Credit per Transaction
-- Expected Result: 0 discrepancy rows
-- -----------------------------------------------------------------------------
SELECT 
    t.transaction_id,
    t.transaction_ref,
    t.amount AS transaction_amount,
    COALESCE(SUM(CASE WHEN al.entry_type = 'DEBIT' THEN (al.amount - t.fee) ELSE 0 END), 0) AS total_principal_debit,
    COALESCE(SUM(CASE WHEN al.entry_type = 'CREDIT' THEN al.amount ELSE 0 END), 0) AS total_principal_credit,
    CASE 
        WHEN COALESCE(SUM(CASE WHEN al.entry_type = 'DEBIT' THEN (al.amount - t.fee) ELSE 0 END), 0) <>
             COALESCE(SUM(CASE WHEN al.entry_type = 'CREDIT' THEN al.amount ELSE 0 END), 0)
        THEN 'FAIL: Unbalanced double-entry ledger'
        ELSE 'PASS'
    END AS reconciliation_status
FROM transactions t
JOIN audit_ledger al ON t.transaction_id = al.transaction_id
WHERE t.transaction_status = 'COMPLETED'
GROUP BY t.transaction_id, t.transaction_ref, t.amount, t.fee
HAVING COALESCE(SUM(CASE WHEN al.entry_type = 'DEBIT' THEN (al.amount - t.fee) ELSE 0 END), 0) <>
       COALESCE(SUM(CASE WHEN al.entry_type = 'CREDIT' THEN al.amount ELSE 0 END), 0);


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-REC-02 (Fee Calculation Precision Audit)
-- Objective: Validate that the transaction fee is accurately charged at 1.0%
-- Business Rule: fee == ROUND(amount * 0.01, 2)
-- Expected Result: 0 mismatched rows
-- -----------------------------------------------------------------------------
SELECT 
    transaction_id,
    transaction_ref,
    amount,
    fee AS actual_fee,
    ROUND(amount * 0.01, 2) AS expected_fee,
    ABS(fee - ROUND(amount * 0.01, 2)) AS variance,
    'FAIL: Incorrect fee calculated' AS defect_flag
FROM transactions
WHERE fee <> ROUND(amount * 0.01, 2);


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-REC-03 (Audit Ledger vs Current Balance Consistency)
-- Objective: Verify that the latest 'balance_after' recorded in audit_ledger
--            for any wallet matches the wallet's current balance.
-- Expected Result: 0 mismatched rows (No unrecorded balance drift)
-- -----------------------------------------------------------------------------
WITH LatestLedgerEntry AS (
    SELECT 
        wallet_id,
        balance_after,
        ROW_NUMBER() OVER(PARTITION BY wallet_id ORDER BY recorded_at DESC, entry_id DESC) as rn
    FROM audit_ledger
)
SELECT 
    w.wallet_id,
    w.balance AS live_wallet_balance,
    lle.balance_after AS ledger_recorded_balance,
    (w.balance - lle.balance_after) AS balance_drift,
    'FAIL: Balance drift detected between ledger and live wallet' AS defect_flag
FROM wallets w
JOIN LatestLedgerEntry lle ON w.wallet_id = lle.wallet_id AND lle.rn = 1
WHERE w.balance <> lle.balance_after;
