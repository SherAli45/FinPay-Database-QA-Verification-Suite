-- ==============================================================================
-- SUITE 03: BOUNDARY VALUES & CONSTRAINT VERIFICATION
-- Focus: Negative values, Limit thresholds, Idempotency, and Decimal Precision
-- ==============================================================================

-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-BND-01 (Negative & Zero Balance Prevention)
-- Objective: Verify no wallet exists with a negative balance (< 0.00)
-- Business Rule: Overdraft not supported; balance MUST be >= 0.00
-- Expected Result: 0 rows returned
-- -----------------------------------------------------------------------------
SELECT 
    wallet_id,
    account_id,
    balance,
    'FAIL: Negative wallet balance detected' AS defect_flag
FROM wallets
WHERE balance < 0.00;


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-BND-02 (Daily Limit Boundary Violation Check)
-- Objective: Find any sender wallet whose total completed outgoing transfers
--            within the last 24 hours exceed their configured daily_transfer_limit.
-- Expected Result: 0 rows returned
-- -----------------------------------------------------------------------------
WITH DailyOutgoing AS (
    SELECT 
        sender_wallet_id AS wallet_id,
        SUM(amount) AS total_sent_today
    FROM transactions
    WHERE transaction_status = 'COMPLETED'
      AND created_at >= (CURRENT_TIMESTAMP - INTERVAL '24 hours')
    GROUP BY sender_wallet_id
)
SELECT 
    w.wallet_id,
    w.daily_transfer_limit,
    d.total_sent_today,
    (d.total_sent_today - w.daily_transfer_limit) AS limit_overflow,
    'FAIL: Daily transfer limit exceeded without rejection' AS defect_flag
FROM wallets w
JOIN DailyOutgoing d ON w.wallet_id = d.wallet_id
WHERE d.total_sent_today > w.daily_transfer_limit;


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-BND-03 (Decimal Precision Truncation Leak Check)
-- Objective: Detect transactions where fractional cents (more than 2 decimal places)
--            exist, preventing floating-point rounding exploits.
-- Expected Result: 0 rows returned
-- -----------------------------------------------------------------------------
SELECT 
    transaction_id,
    transaction_ref,
    amount,
    'FAIL: Amount violates two-decimal-place monetary standard' AS defect_flag
FROM transactions
WHERE amount <> ROUND(amount, 2);


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-BND-04 (Duplicate Idempotency Key Detection)
-- Objective: Verify that idempotency keys are strictly unique across all transactions
-- Expected Result: 0 duplicate rows
-- -----------------------------------------------------------------------------
SELECT 
    idempotency_key,
    COUNT(*) AS occurrence_count,
    'FAIL: Replay attack vulnerability - duplicate idempotency key' AS defect_flag
FROM transactions
WHERE idempotency_key IS NOT NULL
GROUP BY idempotency_key
HAVING COUNT(*) > 1;
