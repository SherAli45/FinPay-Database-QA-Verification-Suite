/**
 * ==============================================================================
 * FINPAY AUTOMATED DATABASE QA TEST RUNNER
 * Author: Sher Ali (Software QA Engineer)
 * Description: Executes SQL test suites, validates zero-defect results,
 *              and outputs an automated QA execution report.
 * ==============================================================================
 */

const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

const DB_CONFIG = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'finpay_qa_db',
};

async function runDatabaseQASuite() {
  console.log('\n======================================================');
  console.log('🚀 FINPAY DATABASE QA AUTOMATED TEST SUITE');
  console.log(`🎯 Target Database: ${DB_CONFIG.database}@${DB_CONFIG.host}`);
  console.log('======================================================\n');

  const client = new Client(DB_CONFIG);

  try {
    await client.connect();
    console.log('✅ Connected to Database successfully.\n');

    const testSuites = [
      { name: 'Suite 01: Data Integrity & Relationships', file: '../test_suites/01_data_integrity_tests.sql' },
      { name: 'Suite 02: Financial Reconciliation & Ledger', file: '../test_suites/02_financial_reconciliation_audit.sql' },
      { name: 'Suite 03: Boundary & Constraint Checks', file: '../test_suites/03_boundary_and_constraint_tests.sql' },
      { name: 'Suite 04: Fraud & Anomaly Audits', file: '../test_suites/04_fraud_and_anomaly_detection.sql' },
    ];

    let totalTests = 0;
    let passedTests = 0;
    let failedTests = 0;

    for (const suite of testSuites) {
      console.log(`\n📋 Executing ${suite.name}...`);
      const filePath = path.join(__dirname, suite.file);

      if (!fs.existsSync(filePath)) {
        console.error(`⚠️ Test file not found: ${filePath}`);
        continue;
      }

      const sqlContent = fs.readFileSync(filePath, 'utf-8');
      const queries = sqlContent
        .split(';')
        .map(q => q.trim())
        .filter(q => q.length > 0 && !q.startsWith('--'));

      for (let i = 0; i < queries.length; i++) {
        totalTests++;
        const query = queries[i];
        const tcMatch = query.match(/TC-DB-[A-Z0-9-]+/i);
        const testId = tcMatch ? tcMatch[0] : `TEST-${i + 1}`;

        try {
          const res = await client.query(query);
          if (res.rows.length === 0) {
            console.log(`  ✅ [PASS] ${testId}: 0 defect rows detected.`);
            passedTests++;
          } else {
            console.error(`  ❌ [FAIL] ${testId}: ${res.rows.length} defect row(s) detected!`);
            console.table(res.rows);
            failedTests++;
          }
        } catch (err) {
          console.error(`  ⚠️ [ERROR] ${testId}: Query execution failed - ${err.message}`);
          failedTests++;
        }
      }
    }

    console.log('\n======================================================');
    console.log('📊 QA EXECUTION SUMMARY');
    console.log(`Total Test Queries: ${totalTests}`);
    console.log(`✅ Passed: ${passedTests}`);
    console.log(`❌ Failed: ${failedTests}`);
    console.log(`Success Rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
    console.log('======================================================\n');

    process.exit(failedTests > 0 ? 1 : 0);

  } catch (error) {
    console.error('❌ Database connection error:', error.message);
    console.log('\n💡 Note for Local Demonstration:');
    console.log('Ensure PostgreSQL is running, or execute queries directly in pgAdmin / DBeaver.');
    process.exit(1);
  } finally {
    await client.end().catch(() => {});
  }
}

if (require.main === module) {
  runDatabaseQASuite();
}

module.exports = { runDatabaseQASuite };
