# 📑 FinPay Database Testing Master Plan

**Document Version:** 1.0.0  
**Author:** Sher Ali (Lead QA Engineer)  
**Target Environment:** PostgreSQL 14+ / Enterprise Financial Ledger  

---

## 1. 🎯 Purpose & Scope
This test plan defines the testing strategy, tooling, and execution methodology for validating data integrity, double-entry bookkeeping reconciliation, boundary limits, and fraud anomaly detection for the **FinPay Core Banking Ledger Database**.

### In-Scope:
* **Schema Integrity:** Primary Keys, Foreign Keys, Unique constraints, NULL integrity.
* **Double-Entry Ledger Accounting:** Validating that every completed transaction adheres to `SUM(Debits) == SUM(Credits)`.
* **Balance Consistency:** Live wallet balance vs. Ledger audit trail parity.
* **Boundary & Negative Testing:** Overflow limits, negative balance prevention, decimal truncation errors.
* **Fraud Detection:** High-velocity transaction bursts, unauthorized transactions on locked wallets.

---

## 2. 🧪 Test Strategy & Levels

| Test Level | Focus Area | Verification Method |
| :--- | :--- | :--- |
| **Level 1: Schema Constraints** | Column constraints, defaults, types | DDL verification & negative insert tests |
| **Level 2: Referential Integrity** | Cascade rules, orphan prevention | Orphaned foreign key joins |
| **Level 3: Financial Reconciliation** | Double-entry bookkeeping balance | Analytical window functions & aggregated groupings |
| **Level 4: Transaction Concurrency** | Race condition audit, locking | Idempotency key duplication & isolation tests |

---

## 3. 🏁 Entry & Exit Criteria

### Entry Criteria:
- [x] Schema DDL deployed to target test database.
- [x] Baseline seed fixtures populated.
- [x] Database user with read/audit permissions provisioned.

### Exit Criteria:
- 100% of P0 & P1 reconciliation queries pass with 0 discrepancies.
- Zero orphaned records detected across accounts, wallets, and audit ledger.
- All high-severity defects logged in Jira with reproducible SQL queries.
