-- ==============================================================================
-- FINPAY DATABASE SCHEMA: CORE BANKING & DIGITAL WALLET LEDGER
-- Environment: PostgreSQL 14+ / ANSI SQL
-- Description: Core tables for Accounts, Wallets, Transactions, and Double-Entry Ledger
-- ==============================================================================

-- Drop existing tables for fresh setup
DROP TABLE IF EXISTS fraud_alerts CASCADE;
DROP TABLE IF EXISTS audit_ledger CASCADE;
DROP TABLE IF EXISTS transactions CASCADE;
DROP TABLE IF EXISTS wallets CASCADE;
DROP TABLE IF EXISTS accounts CASCADE;

-- 1. ACCOUNTS TABLE
CREATE TABLE accounts (
    account_id SERIAL PRIMARY KEY,
    account_number VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    account_status VARCHAR(20) DEFAULT 'ACTIVE' CHECK (account_status IN ('ACTIVE', 'SUSPENDED', 'CLOSED', 'UNDER_REVIEW')),
    kyc_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. WALLETS TABLE
CREATE TABLE wallets (
    wallet_id SERIAL PRIMARY KEY,
    account_id INT NOT NULL REFERENCES accounts(account_id) ON DELETE RESTRICT,
    wallet_type VARCHAR(20) DEFAULT 'STANDARD' CHECK (wallet_type IN ('STANDARD', 'PREMIUM', 'BUSINESS')),
    currency VARCHAR(3) DEFAULT 'USD' CHECK (currency IN ('USD', 'EUR', 'GBP', 'PKR')),
    balance DECIMAL(15, 2) NOT NULL DEFAULT 0.00 CHECK (balance >= 0.00), -- Hard constraint: No negative balance
    daily_transfer_limit DECIMAL(15, 2) NOT NULL DEFAULT 5000.00,
    is_locked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. TRANSACTIONS TABLE
CREATE TABLE transactions (
    transaction_id SERIAL PRIMARY KEY,
    transaction_ref VARCHAR(36) UNIQUE NOT NULL, -- UUID or unique reference
    sender_wallet_id INT NOT NULL REFERENCES wallets(wallet_id),
    receiver_wallet_id INT NOT NULL REFERENCES wallets(wallet_id),
    amount DECIMAL(15, 2) NOT NULL CHECK (amount > 0.00),
    fee DECIMAL(10, 2) NOT NULL DEFAULT 0.00 CHECK (fee >= 0.00),
    transaction_status VARCHAR(20) DEFAULT 'PENDING' CHECK (transaction_status IN ('PENDING', 'COMPLETED', 'FAILED', 'REVERSED')),
    idempotency_key VARCHAR(64) UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_different_wallets CHECK (sender_wallet_id <> receiver_wallet_id)
);

-- 4. DOUBLE-ENTRY AUDIT LEDGER
CREATE TABLE audit_ledger (
    entry_id SERIAL PRIMARY KEY,
    transaction_id INT NOT NULL REFERENCES transactions(transaction_id) ON DELETE RESTRICT,
    wallet_id INT NOT NULL REFERENCES wallets(wallet_id),
    entry_type VARCHAR(6) NOT NULL CHECK (entry_type IN ('DEBIT', 'CREDIT')),
    amount DECIMAL(15, 2) NOT NULL CHECK (amount > 0.00),
    balance_after DECIMAL(15, 2) NOT NULL CHECK (balance_after >= 0.00),
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. FRAUD ALERTS TABLE
CREATE TABLE fraud_alerts (
    alert_id SERIAL PRIMARY KEY,
    transaction_id INT REFERENCES transactions(transaction_id),
    wallet_id INT NOT NULL REFERENCES wallets(wallet_id),
    risk_score INT CHECK (risk_score BETWEEN 0 AND 100),
    trigger_rule VARCHAR(100) NOT NULL,
    alert_status VARCHAR(20) DEFAULT 'OPEN' CHECK (alert_status IN ('OPEN', 'INVESTIGATING', 'RESOLVED', 'DISMISSED')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for Query Performance and QA Auditing
CREATE INDEX idx_transactions_sender ON transactions(sender_wallet_id);
CREATE INDEX idx_transactions_receiver ON transactions(receiver_wallet_id);
CREATE INDEX idx_transactions_ref ON transactions(transaction_ref);
CREATE INDEX idx_ledger_tx ON audit_ledger(transaction_id);
