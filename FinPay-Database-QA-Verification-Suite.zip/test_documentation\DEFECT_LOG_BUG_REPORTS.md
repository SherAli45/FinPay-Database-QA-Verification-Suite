# 🐞 FinPay Database Defect Log & QA Bug Reports

**Project:** FinPay Digital Wallet & Core Banking Ledger  
**Tester:** Sher Ali (QA Engineer)  

---

### 🔴 BUG-101: Floating-Point Truncation Error Causing $0.01 Ledger Discrepancy
* **Severity:** High (S2) | **Priority:** High (P1)
* **Status:** Open | **Component:** Transactions / Fee Engine
* **Found in Test:** `TC-DB-REC-02 (Fee Calculation Precision Audit)`

**Description:**
Transactions with fractional pennies (e.g. transfers involving $149.99 with a 1.5% fee) resulted in floating-point roundoff truncation instead of banker's rounding (`ROUND(val, 2)`), leading to a persistent cumulative drift in the audit ledger.

**SQL Evidence Query:**
```sql
SELECT transaction_id, amount, fee, ROUND(amount * 0.015, 2) AS expected_fee
FROM transactions 
WHERE fee <> ROUND(amount * 0.015, 2);
```

**Expected Result:**
Database or backend service must use `DECIMAL(15, 2)` arithmetic throughout without IEEE-754 float casting.

---

### 🔴 BUG-102: Missing CHECK Constraint Allowed Temporary Negative Balance
* **Severity:** Critical (S1) | **Priority:** Blocker (P0)
* **Status:** Resolved | **Component:** Wallets Table DDL
* **Found in Test:** `TC-DB-BND-01 (Negative & Zero Balance Prevention)`

**Description:**
During concurrent debit withdrawals, the wallet balance dropped to `-$120.00` because the database schema was missing an explicit `CHECK (balance >= 0.00)` constraint, relying solely on application-layer validation.

**Remediation:**
Added database-level invariant:
```sql
ALTER TABLE wallets ADD CONSTRAINT chk_positive_balance CHECK (balance >= 0.00);
```

---

### 🟡 BUG-103: Orphaned Audit Ledger Entry on Transaction Rollback
* **Severity:** Medium (S3) | **Priority:** Medium (P2)
* **Status:** In Review | **Component:** Database Transaction Isolation
* **Found in Test:** `TC-DB-INT-02 (Referential Integrity Check)`

**Description:**
When a target wallet was locked, the transaction status was updated to `FAILED`, but an asynchronous worker still inserted an initial debit ledger row before rolling back, leaving an orphaned ledger row.
