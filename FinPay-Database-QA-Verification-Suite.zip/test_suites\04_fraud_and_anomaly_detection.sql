-- ==============================================================================
-- SUITE 04: FRAUD & ANOMALY DETECTION QA AUDIT
-- Focus: Velocity checks, Transfers on locked/unverified accounts, Risk rules
-- ==============================================================================

-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-FRD-01 (Transfers Involving Locked or Suspended Wallets)
-- Objective: Verify that NO completed transaction exists where either the sender
--            or receiver wallet was locked or parent account suspended.
-- Expected Result: 0 rows returned
-- -----------------------------------------------------------------------------
SELECT 
    t.transaction_id,
    t.transaction_ref,
    t.transaction_status,
    w_sender.wallet_id AS sender_id,
    w_sender.is_locked AS sender_locked,
    w_receiver.wallet_id AS receiver_id,
    w_receiver.is_locked AS receiver_locked,
    'FAIL: Completed transaction executed on locked wallet' AS defect_flag
FROM transactions t
JOIN wallets w_sender ON t.sender_wallet_id = w_sender.wallet_id
JOIN wallets w_receiver ON t.receiver_wallet_id = w_receiver.wallet_id
WHERE t.transaction_status = 'COMPLETED'
  AND (w_sender.is_locked = TRUE OR w_receiver.is_locked = TRUE);


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-FRD-02 (High-Velocity Transaction Burst Audit)
-- Objective: Detect suspicious velocity: More than 5 transactions in under 2 minutes
--            from the same sender (card testing / bot transaction pattern).
-- Expected Result: 0 rows returned (or properly tagged by fraud engine)
-- -----------------------------------------------------------------------------
SELECT 
    t1.sender_wallet_id,
    COUNT(t2.transaction_id) AS rapid_transaction_count,
    'WARNING: High-velocity transaction burst detected' AS defect_flag
FROM transactions t1
JOIN transactions t2 ON t1.sender_wallet_id = t2.sender_wallet_id
                    AND t2.created_at BETWEEN t1.created_at AND (t1.created_at + INTERVAL '2 minutes')
GROUP BY t1.sender_wallet_id, t1.created_at
HAVING COUNT(t2.transaction_id) > 5;


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-FRD-03 (KYC Verification Enforcement Check)
-- Objective: Verify that high-value transactions (> $5,000.00) are only initiated
--            by KYC-verified accounts.
-- Expected Result: 0 rows returned
-- -----------------------------------------------------------------------------
SELECT 
    t.transaction_id,
    t.amount,
    a.account_number,
    a.kyc_verified,
    'FAIL: High value transfer allowed for unverified KYC account' AS defect_flag
FROM transactions t
JOIN wallets w ON t.sender_wallet_id = w.wallet_id
JOIN accounts a ON w.account_id = a.account_id
WHERE t.amount > 5000.00
  AND t.transaction_status = 'COMPLETED'
  AND a.kyc_verified = FALSE;
