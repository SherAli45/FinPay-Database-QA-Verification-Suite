-- ==============================================================================
-- SUITE 01: DATA INTEGRITY & RELATIONSHIP VERIFICATION
-- Focus: Foreign Keys, Orphaned Records, NULL Integrity, and Referential Checks
-- ==============================================================================

-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-INT-01
-- Objective: Detect orphaned records in 'wallets' table without matching 'accounts'
-- Expected Result: 0 rows returned (Zero orphaned wallets)
-- -----------------------------------------------------------------------------
SELECT 
    w.wallet_id,
    w.account_id,
    w.balance,
    'FAIL: Orphaned wallet found without parent account' AS defect_flag
FROM wallets w
LEFT JOIN accounts a ON w.account_id = a.account_id
WHERE a.account_id IS NULL;


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-INT-02
-- Objective: Verify all 'audit_ledger' entries map to a valid 'transactions' row
-- Expected Result: 0 rows returned (Every ledger line has an associated transaction)
-- -----------------------------------------------------------------------------
SELECT 
    al.entry_id,
    al.transaction_id,
    al.entry_type,
    al.amount,
    'FAIL: Ledger entry with non-existent transaction' AS defect_flag
FROM audit_ledger al
LEFT JOIN transactions t ON al.transaction_id = t.transaction_id
WHERE t.transaction_id IS NULL;


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-INT-03
-- Objective: Check for invalid NULL or empty strings in mandatory business fields
-- Expected Result: 0 rows returned
-- -----------------------------------------------------------------------------
SELECT 
    account_id,
    account_number,
    full_name,
    email,
    'FAIL: Mandatory field contains NULL or Whitespace' AS defect_flag
FROM accounts
WHERE account_number IS NULL 
   OR TRIM(account_number) = ''
   OR email IS NULL 
   OR TRIM(email) = ''
   OR full_name IS NULL 
   OR TRIM(full_name) = '';


-- -----------------------------------------------------------------------------
-- TEST CASE ID: TC-DB-INT-04
-- Objective: Verify that no transaction has sender_wallet_id equal to receiver_wallet_id (Self-Transfer check)
-- Expected Result: 0 rows returned
-- -----------------------------------------------------------------------------
SELECT 
    transaction_id,
    transaction_ref,
    sender_wallet_id,
    receiver_wallet_id,
    'FAIL: Self-transfer transaction detected' AS defect_flag
FROM transactions
WHERE sender_wallet_id = receiver_wallet_id;
